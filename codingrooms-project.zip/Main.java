import java.util.*;

public class Main {
    public static void main(String[] args) {
        MapAndPick.addData();//calls the method that fills the 2D data array

        Scanner scan = new Scanner(System.in);
        System.out.println("Welcome to the Valorant Counterpick Calculator!");
        
        //creates the while loop that the UI runs in, which breaks when the user indicates if they want to exit
        boolean exit = false;
        while (exit == false){
            System.out.println("What would you like to do?");
            //displays all the main options that are available for the user to do (options 3 if only avaiable if they have created an agent and 4-5 is if they have 2 full teams created)
            System.out.println("0. Exit \n1. Create Agents\n2. See list of all possible Agents\n3. Agent functions\n4. Check counterpicks\n5. Find best map\n6. Autofill Teams");
            
            int option = scan.nextInt();

            //option that causes the loop to break and for the program to close
            if (option == 0){
                exit=true;
            } 
            
            //option that allows users to create agents
            else if (option == 1){
                if(Agents.totalAgents<10){ //checks if the user has made less than 10 agents, with 10 being the limit of amount of allowed agents
                    System.out.println("How detailed would you like to make your Agent?");

                    //provides options of how detqailed 
                    System.out.println("1. Most detail (Recommended)\n2. Less detail\n3. Least Detail");
                    option = scan.nextInt();
                    if (option==1){
                        System.out.println("What's your agents name (only real agents are allowed)?");
                        String name = scan.next();
                        if (MapAndPick.findPosition(name)!=-1){
                            System.out.println("What team do you want your Agent to be on (1 or 2)?");
                            int team = scan.nextInt();
                            if (team!=1&&team!=2){
                                System.out.println("Requested team doesn't exist, please restart creation process.");
                                back();
                            } else {
                                System.out.println("How many credits does your agent have(cannot exceed 9000, whole numbers only)?");
                                int credits = scan.nextInt();
                                if (credits>9000 || credits<0){
                                    System.out.println("Credits cannot exceed 9000 or be less than 0, please restart creation process.");
                                    back();
                                } else {
                                    System.out.println("How many kills does your agent have?");
                                    int kills = scan.nextInt();
                                    if(kills<0){
                                        System.out.println("Kills cannot be a negative value, please restart creation process.");
                                        back();
                                    } else {
                                        System.out.println("How many deaths does your agent have?");
                                        int deaths = scan.nextInt();
                                        if (deaths<0){
                                            System.out.println("You cannot die negative times, please restart creation process.");
                                            back();
                                        } else {
                                            Agents.allAgents[Agents.totalAgents] = new Agents(name, team, credits, kills, deaths);
                                            System.out.println("Agent " + name + " Created!");
                                            back();
                                        }
                                    }
                                }
                            }
                        } else {
                            System.out.println("Agent requested doesn't exist, please refer to list of all possible Agents.");
                            back();
                        }
                    }else if (option == 2){
                        System.out.println("What's your agents name (only real agents are allowed)?");
                        String name = scan.next();
                        if (MapAndPick.findPosition(name)!=-1){
                            System.out.println("What team do you want your Agent to be on (1 or 2)?");
                            int team = scan.nextInt();
                            if (team!=1&&team!=2){
                                System.out.println("Requested team doesn't exist, please restart creation process.");
                                back();
                            } else {
                                Agents.allAgents[Agents.totalAgents] = new Agents(name, team);
                                System.out.println("Agent " + name + " Created!");
                                back();
                            }
                        }     
                        else {
                            System.out.println("Agent requested doesn't exist, please refer to list of all possible Agents.");
                            back();
                        } 
                    }else if (option == 3){
                        System.out.println("What's your agents name (only real agents are allowed)?");
                        String name = scan.next();
                        if (MapAndPick.findPosition(name)!=-1){
                            Agents.allAgents[Agents.totalAgents] = new Agents(name);
                            System.out.println("Agent " + name + " Created!");
                            back();
                        } else {
                            System.out.println("Agent requested doesn't exist, please refer to list of all possible Agents.");
                            back();
                        }
                    } else {
                        System.out.println("Option doesn't exist.");
                        back();
                    }
                }else{
                    System.out.println("You cannot create anymore agents");
                    back();
                }    
            } else if (option == 2){
                MapAndPick.displayAgents();
                back();
            } else if (option == 3){
                if (Agents.totalAgents>0){
                    System.out.println("Which agent would you like to analyse?");
                    Agents.allAgentsCreated();
                    int agentChosen = scan.nextInt();
                    if (agentChosen>Agents.totalAgents||agentChosen<0){
                        System.out.println("Agent requested doesn't exist.");
                        back();
                    } else {
                        System.out.println("What would you like to do?");
                        System.out.println("1. Add Credits\n2. Spend Credits\n3. Check Balance\n4. Add/Remove Kills\n5. Add/Remove Deaths\n6. Get KD Ratio\n7. Change Teams\n8. Swicth teams with another Agent\n9. Get current teams");
                        option = scan.nextInt();
                        if (option==1){
                            System.out.println("How many credits do you want to add?");
                            int add = scan.nextInt();
                            Agents.allAgents[agentChosen-1].addCreds(add);
                            back();
                        } else if (option==2){
                            System.out.println("How many credits do you want to spend?");
                            int spend = scan.nextInt();
                            Agents.allAgents[agentChosen-1].spendCreds(spend);
                            back();
                        } else if (option==3){
                            System.out.println("You currently have "+ Agents.allAgents[agentChosen-1].getCreds()+"credits.");
                            back();
                        } else if (option==4){
                            System.out.println("How many kills do you want to add/remove?");
                            int kills = scan.nextInt();
                            Agents.allAgents[agentChosen-1].changeKills(kills);
                            back();
                        } else if (option==5){
                            System.out.println("How many deaths do you want to add/remove?");
                            int deaths = scan.nextInt();
                            Agents.allAgents[agentChosen-1].changeDeaths(deaths);
                            back();
                        } else if (option==6){
                            Agents.allAgents[agentChosen-1].getKD();
                            back();
                        } else if (option==7){
                            System.out.println("What team do you want to change to?");
                            int team = scan.nextInt();
                            Agents.allAgents[agentChosen-1].setTeam(team);
                            back();
                        } else if (option==8){
                            if (Agents.totalAgents>=2){
                                System.out.println("Which agent do you want to swap with?");
                                Agents.allAgentsCreated();
                                int agentChosen2 = scan.nextInt();
                                if (agentChosen2>Agents.totalAgents||agentChosen2<0){
                                    System.out.println("Option or Agent requested doesn't exist.");
                                    back();
                                } else if (agentChosen2==agentChosen){
                                    System.out.println("You cannot swap teams with yourself.");
                                    back();
                                } else {
                                    Agents.allAgents[agentChosen-1].swapTeam(Agents.allAgents[agentChosen2-1]);
                                    back();
                                }
                            } else {
                                System.out.println("Create more agents! You cannot swap teams with another agent if there is only 1!");
                                back();
                            }
                        } else if (option==9){
                            if (Agents.totalAgents==10){
                                Agents.getTeams();
                                back();
                            } else {
                                System.out.println("Create more agents, teams are not filled.");
                                back();
                            }
                        }
                    }
                }else{
                    System.out.println("No agents have been created! Create an agent before attempting use this.");
                    back();
                }
            } else if (option == 4){
                if (Agents.totalAgents>0){
                    System.out.println("Which agent would you like to analyse?");
                    Agents.allAgentsCreated();
                    int agentChosen = scan.nextInt();
                    if (agentChosen>Agents.totalAgents||agentChosen<0){
                        System.out.println("Agent requested doesn't exist.");
                        back();
                    } else {
                        if (Agents.allAgents[agentChosen-1].team==2){
                            MapAndPick.findCounter(Agents.allNames[agentChosen-1], 1);
                            back();
                        } else {
                            MapAndPick.findCounter(Agents.allNames[agentChosen-1], 2);
                            back();
                        }
                    }
                }else{
                    System.out.println("No agents have been created! Create an agent before attempting use this.");
                    back();
                }
            } else if (option == 5){
                if (Agents.totalAgents>0){
                    System.out.println("Which team would you like to analyse (1 or 2)?");
                    int team = scan.nextInt();
                    MapAndPick.findMap(team);
                    back();
                }else{
                    System.out.println("No agents have been created! Create an agent before attempting use this.");
                    back();
                }
            } else if (option == 6){
                for (int i = Agents.totalAgents; i<10;i++){
                    Agents.allAgents[Agents.totalAgents] = new Agents(MapAndPick.data[0][(int)(Math.random()*23)]);
                }
                System.out.println("All remaining slots have been filled!");
                Agents.sortTeams();
                back();
            }else{
                System.out.println("Option doesn't exist.");
                back();
            }
        }
    } 

    public static void back(){
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter any key to return to menu.");
        scan.next();
    } 
}